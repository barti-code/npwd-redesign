export const PLAYER_IDENITIFER = '1234';
