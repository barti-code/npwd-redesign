import { mainLogger } from '../sv_logger';

export const photoLogger = mainLogger.child({ module: 'photo' });
