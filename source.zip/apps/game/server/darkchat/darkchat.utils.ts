import { mainLogger } from '../sv_logger';

export const darkchatLogger = mainLogger.child({ module: 'darkchat' });
