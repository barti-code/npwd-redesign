import { mainLogger } from '../sv_logger';

export const notesLogger = mainLogger.child({ module: 'notes' });
