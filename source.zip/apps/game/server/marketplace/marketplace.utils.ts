import { mainLogger } from '../sv_logger';

export const marketplaceLogger = mainLogger.child({ module: 'marketplace' });
