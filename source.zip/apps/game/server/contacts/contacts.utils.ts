import { mainLogger } from '../sv_logger';

export const contactsLogger = mainLogger.child({ module: 'contact' });
