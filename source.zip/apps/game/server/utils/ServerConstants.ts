export enum FetchDefaultLimits {
  NOTES_FETCH_LIMIT = 20,
  CALLS_FETCH_LIMIT = 50,
  CONTACTS_FETCH_LIMIT = 20,
}
