import { mainLogger } from '../sv_logger';

export const bridgeLogger = mainLogger.child({ module: 'bridge' });
