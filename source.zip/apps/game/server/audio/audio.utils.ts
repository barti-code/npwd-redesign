import { mainLogger } from '../sv_logger';

export const audioLogger = mainLogger.child({ module: 'audio' });
