// eslint-disable-next-line @typescript-eslint/no-empty-function
export const noop = () => {};
