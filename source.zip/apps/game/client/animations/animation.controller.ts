import { AnimationService } from './animation.service';

export const animationService = new AnimationService();
