import { RegisterNuiProxy } from './cl_utils';
import { AudioEvents } from '@typings/audio';

RegisterNuiProxy(AudioEvents.UPLOAD_AUDIO);
