import React from 'react';
import { Email } from '@mui/icons-material';

const EmailIcon: React.FC = () => <Email fontSize="large" />;

export default EmailIcon;
