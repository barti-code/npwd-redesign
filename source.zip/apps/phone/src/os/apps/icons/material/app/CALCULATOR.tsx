import React from 'react';
import { Calculator as LCalc } from 'lucide-react';

const Calculator: React.FC = () =><LCalc size={30} />;

export default Calculator;
