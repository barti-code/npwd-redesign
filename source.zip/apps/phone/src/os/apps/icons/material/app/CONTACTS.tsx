import React from 'react';
import { BookUser } from 'lucide-react';

const ContactIcon: React.FC = () => <BookUser size={30} />;

export default ContactIcon;
