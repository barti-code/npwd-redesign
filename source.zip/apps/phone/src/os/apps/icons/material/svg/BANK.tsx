import { Money } from '@mui/icons-material';
import React from 'react';

const BankIcon: React.FC = () => <Money fontSize="small" />;

export default BankIcon;
