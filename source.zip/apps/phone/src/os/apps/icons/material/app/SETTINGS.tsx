import React from 'react';
import { Settings } from 'lucide-react';

const SettingsIcon: React.FC = () => <Settings size={30} />;

export default SettingsIcon;
