import React from 'react';
import { Bird } from 'lucide-react';

const TwitterIcon: React.FC = () => (
  <Bird size={30} />
);

export default TwitterIcon;
