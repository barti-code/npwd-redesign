import React from 'react';
import { Phone } from 'lucide-react';

const DialerIcon: React.FC = () => <Phone size={30} />;

export default DialerIcon;
