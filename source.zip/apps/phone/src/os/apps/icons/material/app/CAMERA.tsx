import React from 'react';
import { Camera as LCamera } from 'lucide-react';

const Camera: React.FC = () => <LCamera size={30} />;

export default Camera;
