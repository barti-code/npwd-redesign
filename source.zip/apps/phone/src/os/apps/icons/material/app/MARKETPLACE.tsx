import React from 'react';
import { Store } from 'lucide-react';

const MarketplaceIcon: React.FC = () => <Store size={30}/>

export default MarketplaceIcon;
