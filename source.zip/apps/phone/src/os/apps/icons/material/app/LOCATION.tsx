import React from 'react';
import { LocationSearching } from '@mui/icons-material';

const LocationIcon: React.FC = () => <LocationSearching fontSize="large" />;

export default LocationIcon;
