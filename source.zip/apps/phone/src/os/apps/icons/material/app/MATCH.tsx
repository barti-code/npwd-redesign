import React from 'react';
import { HeartHandshake } from 'lucide-react';

const MatchIcon: React.FC = () => <HeartHandshake size={30} />

export default MatchIcon;
