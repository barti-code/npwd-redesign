import { ChromeIcon } from 'lucide-react';

const BrowserIcon = () => <ChromeIcon size={30}/>;

export default BrowserIcon;
