import React from 'react';
import { Help } from '@mui/icons-material';

const ExampleIcon: React.FC = () => <Help fontSize="large" />;

export default ExampleIcon;
