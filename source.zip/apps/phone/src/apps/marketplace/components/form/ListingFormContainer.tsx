import React from 'react';
import { ListingForm } from './ListingForm';

export const ListingFormContainer: React.FC = () => {
  return (
    <div>
      <ListingForm />
    </div>
  );
};
