import React from 'react';
import { ContactList } from '../List/ContactList';

export const ContactPage: React.FC = () => {
  return (
    <div className="">
      <ContactList />
    </div>
  );
};