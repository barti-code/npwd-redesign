export const MockPhotoData = [
  {
    id: 1,
    image: 'https://i.imgur.com/7juREyw.png',
  },
  {
    id: 2,
    image: 'https://i.imgur.com/ULWUAoY.png',
  },
  {
    id: 3,
    image: 'https://i.imgur.com/2UScodu.png',
  },
  {
    id: 4,
    image: 'https://i.imgur.com/nNuoTkW.png',
  },
];
