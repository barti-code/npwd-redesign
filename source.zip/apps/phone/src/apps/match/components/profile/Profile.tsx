import React from 'react';
import {
  Box,
  CardContent,
  CardMedia,
  Chip,
  IconButton,
  LinearProgress,
  Typography,
} from '@mui/material';
import makeStyles from '@mui/styles/makeStyles';
import { useTranslation } from 'react-i18next';
import { FormattedProfile, FormattedMatch } from '@typings/match';
import { useAudioPlayer } from '@os/audio/hooks/useAudioPlayer';
import PlayArrowIcon from '@mui/icons-material/PlayArrow';
import PauseIcon from '@mui/icons-material/Pause';

const useStyles = makeStyles({
  tags: {
    position: 'absolute',
    bottom: '40%',
  },
  tag: {
    margin: '3px 3px 0px 0px',
    opacity: '0.8',
  },
  media: {
    height: '60%',
  },
  content: {
    height: '40%',
    overflowY: 'auto',
  },
});

interface IProps {
  profile: FormattedProfile | FormattedMatch;
}

const DEFAULT_IMAGE = 'https://upload.wikimedia.org/wikipedia/commons/a/ac/No_image_available.svg';

const Profile = ({ profile }: IProps) => {
  const c = useStyles();
  const [t] = useTranslation();
  const { play, pause, playing, currentTime, duration } = useAudioPlayer(profile.voiceMessage);

  const calculateProgress =
    isNaN(duration) || duration == Infinity
      ? 0
      : (Math.trunc(currentTime) / Math.trunc(duration)) * 100;

  function parseSecondaryBio(): string | undefined {
    const { location, job } = profile;
    if (location && job) {
      return `${location} - ${job}`;
    } else if (location) {
      return location;
    } else if (job) {
      return job;
    }
  }

  const bioSecondary = parseSecondaryBio();

  return (
    <>
      <CardContent className={c.tags}>
        {profile.tagList.map((tag) => (
          <Chip className={c.tag} label={tag} color="primary" />
        ))}
      </CardContent>
      <CardMedia className={c.media} image={profile.image || DEFAULT_IMAGE} title={profile.name} />
      <CardContent className={c.content}>
        <Typography gutterBottom variant="h4" component="h2">
          {profile.name}
        </Typography>
        <Typography gutterBottom color="textSecondary" component="p">
          {t('MATCH.MESSAGES.PROFILE_LAST_ACTIVE', { lastActive: profile.lastActiveFormatted })}
        </Typography>
        {bioSecondary && (
          <Typography gutterBottom variant="body1" color="textSecondary" component="p">
            {bioSecondary}
          </Typography>
        )}
        <Typography variant="body2" color="textSecondary" component="p">
          {profile.bio}
        </Typography>

        {profile.voiceMessage && (
          <Box>
            <Box display="flex" alignItems="center">
              <IconButton onClick={playing ? pause : play}>
                {playing ? (
                  <PauseIcon sx={{ color: '#232323' }} />
                ) : (
                  <PlayArrowIcon sx={{ color: '#232323' }} />
                )}
              </IconButton>
              <Box sx={{ width: '60%' }}>
                {!calculateProgress && playing ? (
                  <LinearProgress />
                ) : (
                  <LinearProgress variant="determinate" value={calculateProgress} />
                )}
              </Box>
            </Box>
          </Box>
        )}
      </CardContent>
    </>
  );
};

export default Profile;
