export const NPWD_STORAGE_KEY = 'npwd_settings';
export const NPWD_MULTI_STORAGE_KEY = 'npwd_multi_settings';
