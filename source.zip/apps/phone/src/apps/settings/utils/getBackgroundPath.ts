const getBackgroundPath = (bg: string) => `media/backgrounds/${bg}`;

export default getBackgroundPath;
