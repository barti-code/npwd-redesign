import { NoteItem } from '@typings/notes';

export const BrowserNotesData: NoteItem[] = [
  {
    id: 1,
    title: 'You suck',
    content: 'Nice note bro',
  },
  {
    id: 2,
    title: 'You suck',
    content: 'Nice note bro',
  },
  {
    id: 3,
    title: 'You suck',
    content: 'Nice note bro',
  },
  {
    id: 4,
    title: 'You suck',
    content: 'Nice note bro',
  },
];
