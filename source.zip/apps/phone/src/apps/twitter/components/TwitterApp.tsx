import { memo, useState } from 'react';
import { Route, useLocation } from 'react-router-dom';
import { AppWrapper } from '@ui/components';
import { AppContent } from '@ui/components/AppContent';
import TweetListContainer from './tweet/TweetListContainer';
import AddTweetModal from './AddTweetModal';
import TweetButton from './buttons/TweetButton';
import { LifeInvaderTitle } from './TwitterTitle';
import BottomNavigation from './BottomNavigation';
import TwitterProfile from './profile/Profile';
import TwitterSearch from './TwitterSearch';

import './twitter.css';
import 'emoji-mart/css/emoji-mart.css';
import { useProfile } from '../hooks/useProfile';
import ProfilePrompt from './profile/ProfilePrompt';
import { TwitterThemeProvider } from '../providers/TwitterThemeProvider';
import { useSetRecoilState } from 'recoil';
import { twitterState } from '../hooks/state';
import ModalBackground from './ModalBackground';
import { WordFilterProvider } from '@os/wordfilter/providers/WordFilterProvider';
import InjectDebugData from '@os/debug/InjectDebugData';
import { TwitterEvents } from '@typings/twitter';

const TwitterApp = () => {
  const setModalVisible = useSetRecoilState(twitterState.showCreateTweetModal);
  const [activePage, setActivePage] = useState(0);
  const { profile } = useProfile();
  const location = useLocation();

  // before any other action can be taken by the user we force
  // them have a profile name.
  const promptProfileName = !profile || !profile.profile_name || !profile.profile_name.trim();

  const openModal = () => setModalVisible(true);
  const handlePageChange = (_, page) => setActivePage(page);
  const showTweetButton =
    !promptProfileName && activePage === 0 && location.pathname === '/twitter';

  return (
    <TwitterThemeProvider>
      <AppWrapper id="twitter-app">
        <WordFilterProvider>
          <AddTweetModal />
        </WordFilterProvider>
        <LifeInvaderTitle />
        <AppContent>
          {promptProfileName ? (
            <ProfilePrompt />
          ) : (
            <>
              <Route path="/twitter" exact component={TweetListContainer} />
              <Route path="/twitter/search" component={TwitterSearch} />
              <Route path="/twitter/profile" component={TwitterProfile} />
            </>
          )}
        </AppContent>
        {showTweetButton && <TweetButton openModal={openModal} />}
        {!promptProfileName && (
          <BottomNavigation activePage={activePage} handleChange={handlePageChange} />
        )}
      </AppWrapper>
    </TwitterThemeProvider>
  );
};
export default memo(TwitterApp);

InjectDebugData<any>(
  [
    {
      app: 'TWITTER',
      method: TwitterEvents.CREATE_TWEET_BROADCAST,
      data: {
        appId: 'TWITTER',
        profile_id: 423443442,
        profile_name: 'John_White',
        isMine: false,
        isLiked: true,
        retweetId: '',
        isRetweet: false,
        seconds_since_tweet: 1639,
        retweetProfileName: '',
        retweetAvatarUrl: '',
        isReported: false,
        retweetIdentifier: '',
        avatar_url: '',
        id: 116,
        message: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean feugiat eros ut enim lacinia pulvinar. Suspendisse ac condimentum tellus. Maecenas euismod, urna vitae porttitor viverra, ex magna posuere lectus, nec semper velit neque non dui. Cras dapibus lectus sed purus dignissim gravida. Aliquam dignissim purus vitae sapien cursus egestas. Pellentesque gravida massa sit amet mauris pulvinar lobortis. Vivamus gravida erat sit amet eros tempor elementum. Quisque rutrum nulla ac imperdiet pulvinar. Duis a dignissim lacus, ut pulvinar ipsum. Vestibulum in purus quis ligula pretium varius. Suspendisse eu tortor bibendum, porta tortor quis, porttitor quam. Donec dapibus hendrerit nisi ac pellentesque. Quisque porttitor felis sit amet consectetur pharetra. Pellentesque vulputate consequat laoreet. Nulla sed nunc ac leo suscipit sodales. ',
        createdAt: '2024-12-01 00:42:03',
        updatedAt: '2024-12-01 00:42:03',
        identifier: '',
        retweet: null,
      },
    },
  ],
  4000,
);
