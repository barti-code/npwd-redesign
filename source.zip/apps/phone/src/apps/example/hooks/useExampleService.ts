export const useExampleService = () => {
  // If you need some data that you can't get through a fetch, use services / listeners with `useNuiEvent`
};

// call this function in the Phone.tsx file.
