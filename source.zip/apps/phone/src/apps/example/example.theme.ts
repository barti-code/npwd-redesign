import { ThemeOptions } from '@mui/material';

const theme: ThemeOptions = {
  palette: {
    primary: {
      main: '#f23123',
    },
  },
};

export default theme;
