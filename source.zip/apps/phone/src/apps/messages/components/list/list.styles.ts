import makeStyles from '@mui/styles/makeStyles';

const useStyles = makeStyles((theme) => ({
  root: {
    height: '580px',
    overflowY: 'auto',
  },
}));

export default useStyles;
