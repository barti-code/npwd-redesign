# New Phone Who Dis

A FiveM phone created with ReactJS, with the power from TasoOneAsia, erik-sn (Kire), jfrader (kidz), r1OG, RockySouthpaw and itschip. Still missing commits from 99kr.
